#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/point_cloud2_iterator.hpp>

#include <draco/compression/encode.h>
#include <draco/compression/point_cloud/point_cloud_encoder.h>
#include <draco/core/encoder_buffer.h>
#include <draco/point_cloud/point_cloud.h>
#include <draco/point_cloud/point_cloud_builder.h>

#include <boost/beast/core.hpp>
#include <boost/beast/websocket.hpp>
#include <boost/asio/connect.hpp>
#include <boost/asio/ip/tcp.hpp>

#include <iostream>
#include <vector>
#include <chrono>
#include <memory>
#include <unordered_set> // [추가] 중복 복셀 체크용
#include <cmath>         // [추가] floor 함수용

namespace beast = boost::beast;
namespace http = beast::http;
namespace websocket = beast::websocket;
namespace net = boost::asio;
using tcp = boost::asio::ip::tcp;

// [추가] 복셀 인덱스를 저장할 구조체
struct VoxelIndex {
    int x, y, z;

    bool operator==(const VoxelIndex &other) const {
        return x == other.x && y == other.y && z == other.z;
    }
};

// [추가] unordered_set을 위한 해시 함수
struct VoxelHash {
    size_t operator()(const VoxelIndex &k) const {
        // 간단한 해시 결합 (XOR and Shift)
        size_t res = 17;
        res = res * 31 + std::hash<int>()(k.x);
        res = res * 31 + std::hash<int>()(k.y);
        res = res * 31 + std::hash<int>()(k.z);
        return res;
    }
};

class DracoSenderNode : public rclcpp::Node {
public:
    DracoSenderNode() : Node("draco_sender_node") {
        this->declare_parameter("host", "");
        this->declare_parameter("port", "");
        this->declare_parameter("endpoint", "");
        this->declare_parameter("input_topic", "");
        this->declare_parameter("skip_length", 1.0f);
        // [추가] 복셀 사이즈 파라미터 (단위: 미터). 
        // 0.05는 5cm 간격. 이 값보다 가까운 점들은 하나로 합쳐짐(나머지 삭제).
        // 0.0이면 샘플링 안 함.
        this->declare_parameter("voxel_size", 0.001);

        if (!init_websocket()) {
            RCLCPP_ERROR(this->get_logger(), "Failed to initialize WebSocket. Exiting...");
            exit(EXIT_FAILURE);
        }

        std::string topic_name = this->get_parameter("input_topic").as_string();
        subscription_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            topic_name, 
            rclcpp::SensorDataQoS(), 
            std::bind(&DracoSenderNode::topic_callback, this, std::placeholders::_1)
        );

        RCLCPP_INFO(this->get_logger(), "Draco Sender Node Started. Voxel Size: %.3fm", this->get_parameter("voxel_size").as_double());
    }

private:
    net::io_context io_context_;
    std::shared_ptr<websocket::stream<tcp::socket>> ws_;
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr subscription_;

    bool init_websocket() {
        try {
            std::string host = this->get_parameter("host").as_string();
            std::string port = this->get_parameter("port").as_string();
            std::string endpoint = this->get_parameter("endpoint").as_string();

            tcp::resolver resolver(io_context_);
            ws_ = std::make_shared<websocket::stream<tcp::socket>>(io_context_);
            
            auto const results = resolver.resolve(host, port);
            auto ep = net::connect(ws_->next_layer(), results);
            
            std::string host_port = host + ":" + std::to_string(ep.port());
            
            ws_->handshake(host_port, endpoint);
            ws_->binary(false);
            ws_->write(net::buffer("lidar/draco")); 
            ws_->binary(true);
            
            RCLCPP_INFO(this->get_logger(), "Connected to WebSocket: %s", host_port.c_str());
            return true;
        } catch (std::exception &e) {
            RCLCPP_ERROR(this->get_logger(), "WebSocket Init Error: %s", e.what());
            return false;
        }
    }

    draco::EncoderBuffer compress_msg(const sensor_msgs::msg::PointCloud2::SharedPtr msg) {
        sensor_msgs::PointCloud2ConstIterator<float> iter_x(*msg, "x");
        sensor_msgs::PointCloud2ConstIterator<float> iter_y(*msg, "y");
        sensor_msgs::PointCloud2ConstIterator<float> iter_z(*msg, "z");
        
        bool has_rgb = false;
        for (const auto& field : msg->fields) {
            if (field.name == "rgb" || field.name == "rgba") has_rgb = true;
        }

        std::vector<float> point_data;
        std::vector<uint8_t> color_data;
        
        // 예상 크기를 좀 더 보수적으로 잡음 (샘플링 되므로)
        size_t estimated_points = msg->width * msg->height;
        point_data.reserve(estimated_points * 3);
        color_data.reserve(estimated_points * 3);

        // [추가] 샘플링 설정 로드
        double voxel_size = this->get_parameter("voxel_size").as_double();
        double skip_length_ = this->get_parameter("skip_length").as_double();
        bool use_sampling = (voxel_size > 0.001); // 1mm 이하는 샘플링 안함으로 간주
        
        // [추가] 이미 방문한 복셀을 추적하기 위한 Set
        std::unordered_set<VoxelIndex, VoxelHash> visited_voxels;
        // 성능을 위해 대략적인 크기 예약 (해시 충돌 방지)
        if(use_sampling) visited_voxels.reserve(estimated_points / 2);

        if (has_rgb) {
            sensor_msgs::PointCloud2ConstIterator<float> iter_rgb(*msg, "rgb");
            for (; iter_x != iter_x.end(); ++iter_x, ++iter_y, ++iter_z, ++iter_rgb) {
                float x = *iter_x;
                float y = *iter_y;
                float z = *iter_z;

                // 1. 유효성 검사
                if (std::isnan(x) || std::isnan(y) || std::isnan(z)) continue;
                if (x*x + y*y + z*z > skip_length_) continue;

                // 2. [핵심] Voxel Sampling (거리 기반 다운샘플링)
                if (use_sampling) {
                    // 현재 좌표가 어느 그리드 칸(Voxel)에 속하는지 계산
                    VoxelIndex idx;
                    idx.x = static_cast<int>(std::floor(x / voxel_size));
                    idx.y = static_cast<int>(std::floor(y / voxel_size));
                    idx.z = static_cast<int>(std::floor(z / voxel_size));

                    // 이미 이 칸에 점이 등록되어 있다면, 이 점은 건너뜀 (삭제)
                    if (visited_voxels.find(idx) != visited_voxels.end()) {
                        continue; 
                    }
                    // 처음 방문한 칸이라면 기록
                    visited_voxels.insert(idx);
                }

                const uint32_t rgb = *reinterpret_cast<const uint32_t*>(&(*iter_rgb));
                uint8_t r = (rgb >> 16) & 0xFF;
                uint8_t g = (rgb >> 8) & 0xFF;
                uint8_t b = (rgb) & 0xFF;

                if (r == 0 && g == 0 && b == 0) continue;

                point_data.push_back(x);
                point_data.push_back(y);
                point_data.push_back(z);

                color_data.push_back(r);
                color_data.push_back(g);
                color_data.push_back(b);
            }
        }

        // --- (RGB 없는 경우의 로직도 위와 동일하게 적용 가능) ---

        // 결과 확인용 로그 (필요시 주석 해제)
        // std::cout << "Original: " << estimated_points << " -> Sampled: " << point_data.size()/3 << std::endl;
        
        if (point_data.empty()) return draco::EncoderBuffer();

        auto start_time = std::chrono::high_resolution_clock::now();
        
        draco::PointCloudBuilder builder;
        builder.Start(point_data.size() / 3);

        const int pos_att_id = builder.AddAttribute(draco::GeometryAttribute::POSITION, 3, draco::DT_FLOAT32);
        const int color_att_id = builder.AddAttribute(draco::GeometryAttribute::COLOR, 3, draco::DT_UINT8);

        builder.SetAttributeValuesForAllPoints(pos_att_id, point_data.data(), 3 * sizeof(float));
        builder.SetAttributeValuesForAllPoints(color_att_id, color_data.data(), 3 * sizeof(uint8_t));

        std::unique_ptr<draco::PointCloud> draco_cloud = builder.Finalize(false);

        draco::Encoder encoder;
        encoder.SetSpeedOptions(10, 10);
        encoder.SetAttributeQuantization(draco::GeometryAttribute::POSITION, 8); // 8비트 양자화
        encoder.SetAttributeQuantization(draco::GeometryAttribute::COLOR, 3);    // 컬러 압축

        draco::EncoderBuffer buffer;
        draco::Status status = encoder.EncodePointCloudToBuffer(*draco_cloud, &buffer);
//        auto start_time = std::chrono::high_resolution_clock::now();
        auto compression_end = std::chrono::high_resolution_clock::now();
        std::chrono::duration<double, std::milli> duration_comp = compression_end - start_time;
        
        // std::cout << "Compressed: " << duration_comp.count() << "ms" << std::endl;
        
        if (!status.ok()) {
            RCLCPP_ERROR(this->get_logger(), "Draco Encoding Error: %s", status.error_msg());
            return draco::EncoderBuffer();
        }

        return buffer;
    }

    void topic_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg) {
        draco::EncoderBuffer buffer;
        try{
            buffer = compress_msg(msg);
            if (buffer.size() == 0) return;
        } catch(std::exception &e){
            return;
        }

        try {
            ws_->write(net::buffer(buffer.data(), buffer.size()));
        } catch (std::exception &e) {
            RCLCPP_ERROR(this->get_logger(), "WebSocket Write Error: %s", e.what());
        }
    }
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<DracoSenderNode>());
    rclcpp::shutdown();
    return 0;
}
