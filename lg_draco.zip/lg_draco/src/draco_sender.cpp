#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/point_cloud2_iterator.hpp>

// Draco Compression Headers
#include <draco/compression/encode.h>
#include <draco/compression/point_cloud/point_cloud_encoder.h>
#include <draco/core/encoder_buffer.h>
#include <draco/point_cloud/point_cloud.h>
#include <draco/point_cloud/point_cloud_builder.h>

// WebSocket / Network Headers
#include <boost/beast/core.hpp>
#include <boost/beast/websocket.hpp>
#include <boost/asio/connect.hpp>
#include <boost/asio/ip/tcp.hpp>

// Standard Library
#include <iostream>
#include <vector>
#include <chrono>
#include <memory>
#include <unordered_set> 
#include <cmath>         

// TF2 Headers
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <tf2/LinearMath/Transform.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp> 

namespace beast = boost::beast;
namespace http = beast::http;
namespace websocket = beast::websocket;
namespace net = boost::asio;
using tcp = boost::asio::ip::tcp;

// 복셀 인덱싱 구조체
struct VoxelIndex {
    int x, y, z;
    bool operator==(const VoxelIndex &other) const {
        return x == other.x && y == other.y && z == other.z;
    }
};

// 복셀 해시 함수
struct VoxelHash {
    size_t operator()(const VoxelIndex &k) const {
        size_t res = 17;
        res = res * 31 + std::hash<int>()(k.x);
        res = res * 31 + std::hash<int>()(k.y);
        res = res * 31 + std::hash<int>()(k.z);
        return res;
    }
};

class DracoSenderNode : public rclcpp::Node {
public:
    DracoSenderNode() : Node("draco_sender_node") {
        // 파라미터 선언
        this->declare_parameter("host", "cobot.center");
        this->declare_parameter("port", "8286");
        this->declare_parameter("endpoint", "/pang/ws/pub?channel=instant&name=68b7f7e7fed224d70cfa3354&track=point_cloud&mode=bundle");
        this->declare_parameter("input_topic", "/camera/camera/depth/color/points");
        
        // 필터링 파라미터
        this->declare_parameter("voxel_size", 0.001); // 1mm 단위
        this->declare_parameter("skip_length", 1.0f); // 1m 이상 거리는 자름 (카메라 기준)
        
        // TF 타겟 프레임 (예: 로봇의 바닥)
        this->declare_parameter("target_frame", "base_link");

        // TF 리스너 초기화
        tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
        tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

        // 웹소켓 초기화
        if (!init_websocket()) {
            RCLCPP_ERROR(this->get_logger(), "Failed to initialize WebSocket. Exiting...");
            exit(EXIT_FAILURE);
        }

        std::string topic_name = this->get_parameter("input_topic").as_string();
        subscription_ = this->create_subscription<sensor_msgs::msg::PointCloud2>(
            topic_name, 
            rclcpp::SensorDataQoS(), 
            std::bind(&DracoSenderNode::topic_callback, this, std::placeholders::_1)
        );

        RCLCPP_INFO(this->get_logger(), "Draco Sender Node Started.");
        RCLCPP_INFO(this->get_logger(), "Target Frame: %s, Skip Length: %.2fm", 
            this->get_parameter("target_frame").as_string().c_str(),
            this->get_parameter("skip_length").as_double());
    }

private:
    net::io_context io_context_;
    std::shared_ptr<websocket::stream<tcp::socket>> ws_;
    rclcpp::Subscription<sensor_msgs::msg::PointCloud2>::SharedPtr subscription_;
    
    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;

    bool init_websocket() {
        try {
            std::string host = this->get_parameter("host").as_string();
            std::string port = this->get_parameter("port").as_string();
            std::string endpoint = this->get_parameter("endpoint").as_string();

            tcp::resolver resolver(io_context_);
            ws_ = std::make_shared<websocket::stream<tcp::socket>>(io_context_);
            
            auto const results = resolver.resolve(host, port);
            auto ep = net::connect(ws_->next_layer(), results);
            
            std::string host_port = host + ":" + std::to_string(ep.port());
            
            ws_->handshake(host_port, endpoint);
            ws_->binary(false);
            ws_->write(net::buffer("lidar/draco")); 
            ws_->binary(true);
            
            RCLCPP_INFO(this->get_logger(), "Connected to WebSocket: %s", host_port.c_str());
            return true;
        } catch (std::exception &e) {
            RCLCPP_ERROR(this->get_logger(), "WebSocket Init Error: %s", e.what());
            return false;
        }
    }

    draco::EncoderBuffer compress_msg(
        const sensor_msgs::msg::PointCloud2::SharedPtr msg,
        const geometry_msgs::msg::TransformStamped& transform) 
    {
        // 1. TF 메시지를 고속 연산용 행렬로 변환
        tf2::Transform tf_mat;
        tf2::fromMsg(transform.transform, tf_mat);
        
        bool need_transform = (msg->header.frame_id != transform.header.frame_id);

        sensor_msgs::PointCloud2ConstIterator<float> iter_x(*msg, "x");
        sensor_msgs::PointCloud2ConstIterator<float> iter_y(*msg, "y");
        sensor_msgs::PointCloud2ConstIterator<float> iter_z(*msg, "z");
        
        bool has_rgb = false;
        for (const auto& field : msg->fields) {
            if (field.name == "rgb" || field.name == "rgba") has_rgb = true;
        }

        std::vector<float> point_data;
        std::vector<uint8_t> color_data;
        
        size_t estimated_points = msg->width * msg->height;
        point_data.reserve(estimated_points * 3);
        color_data.reserve(estimated_points * 3);

        double voxel_size = this->get_parameter("voxel_size").as_double();
        bool use_sampling = (voxel_size > 0.001); 
        
        double skip_length = this->get_parameter("skip_length").as_double();
        double skip_length_sq = skip_length * skip_length; // 제곱 거리로 비교 (성능 최적화)

        std::unordered_set<VoxelIndex, VoxelHash> visited_voxels;
        if(use_sampling) visited_voxels.reserve(estimated_points / 2);

        if (has_rgb) {
            sensor_msgs::PointCloud2ConstIterator<float> iter_rgb(*msg, "rgb");
            for (; iter_x != iter_x.end(); ++iter_x, ++iter_y, ++iter_z, ++iter_rgb) {
                // [A] 원본 좌표 읽기 (Camera Frame)
                float raw_x = *iter_x;
                float raw_y = *iter_y;
                float raw_z = *iter_z;

                if (std::isnan(raw_x) || std::isnan(raw_y) || std::isnan(raw_z)) continue;

                // [B] 거리 필터링 (원본 좌표 기준)
                // 카메라로부터의 직선 거리가 설정값보다 멀면 제거
                if ((raw_x*raw_x + raw_y*raw_y + raw_z*raw_z) > skip_length_sq) continue; 

                // [C] 좌표 변환 (Camera -> Target Frame)
                float x, y, z;
                if (need_transform) {
                    tf2::Vector3 p_in(raw_x, raw_y, raw_z);
                    tf2::Vector3 p_out = tf_mat * p_in; 
                    x = p_out.x();
                    y = p_out.y();
                    z = p_out.z();
                } else {
                    x = raw_x; y = raw_y; z = raw_z;
                }

                // [D] 복셀 샘플링 (변환된 World 좌표 기준)
                // 로봇 기준 공간에서 겹치는 점들을 하나로 합침
                if (use_sampling) {
                    VoxelIndex idx;
                    idx.x = static_cast<int>(std::floor(x / voxel_size));
                    idx.y = static_cast<int>(std::floor(y / voxel_size));
                    idx.z = static_cast<int>(std::floor(z / voxel_size));

                    if (visited_voxels.find(idx) != visited_voxels.end()) {
                        continue; // 이미 등록된 복셀이면 스킵
                    }
                    visited_voxels.insert(idx);
                }

                const uint32_t rgb = *reinterpret_cast<const uint32_t*>(&(*iter_rgb));
                uint8_t r = (rgb >> 16) & 0xFF;
                uint8_t g = (rgb >> 8) & 0xFF;
                uint8_t b = (rgb) & 0xFF;

                // 검은색(0,0,0) 포인트 제거 옵션 (필요시 사용)
                if (r == 0 && g == 0 && b == 0) continue;

                point_data.push_back(x);
                point_data.push_back(y);
                point_data.push_back(z);

                color_data.push_back(r);
                color_data.push_back(g);
                color_data.push_back(b);
            }
        }

        if (point_data.empty()) return draco::EncoderBuffer();
        
        draco::PointCloudBuilder builder;
        builder.Start(point_data.size() / 3);

        const int pos_att_id = builder.AddAttribute(draco::GeometryAttribute::POSITION, 3, draco::DT_FLOAT32);
        const int color_att_id = builder.AddAttribute(draco::GeometryAttribute::COLOR, 3, draco::DT_UINT8);

        builder.SetAttributeValuesForAllPoints(pos_att_id, point_data.data(), 3 * sizeof(float));
        builder.SetAttributeValuesForAllPoints(color_att_id, color_data.data(), 3 * sizeof(uint8_t));

        std::unique_ptr<draco::PointCloud> draco_cloud = builder.Finalize(false);

        draco::Encoder encoder;
        encoder.SetSpeedOptions(10, 10); // 0(느림/고압축) ~ 10(빠름/저압축)
        encoder.SetAttributeQuantization(draco::GeometryAttribute::POSITION, 12); // 8-16비트 권장
        encoder.SetAttributeQuantization(draco::GeometryAttribute::COLOR, 3);    

        draco::EncoderBuffer buffer;
        draco::Status status = encoder.EncodePointCloudToBuffer(*draco_cloud, &buffer);
        
        if (!status.ok()) {
            RCLCPP_ERROR(this->get_logger(), "Draco Encoding Error: %s", status.error_msg());
            return draco::EncoderBuffer();
        }

        return buffer;
    }

    void topic_callback(const sensor_msgs::msg::PointCloud2::SharedPtr msg) {
        std::string target_frame = this->get_parameter("target_frame").as_string();
        
        // TF 조회
        geometry_msgs::msg::TransformStamped t_stamped;
        try {
            if (msg->header.frame_id != target_frame) {
                // 가장 최신 TF 가져오기
                t_stamped = tf_buffer_->lookupTransform(
                    target_frame, 
                    msg->header.frame_id, 
                    tf2::TimePointZero 
                );
            } else {
                t_stamped.header.frame_id = target_frame;
                t_stamped.child_frame_id = target_frame;
                t_stamped.transform.rotation.w = 1.0;
            }
        } catch (tf2::TransformException &ex) {
            // TF가 아직 준비되지 않았으면 경고 출력 후 이번 프레임 스킵
            RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 2000, "TF Lookup Failed: %s", ex.what());
            return; 
        }

        draco::EncoderBuffer buffer;
        try{
            // 압축 실행 (내부에서 필터링 및 변환 수행)
            buffer = compress_msg(msg, t_stamped);
            if (buffer.size() == 0) return;
        } catch(std::exception &e){
            RCLCPP_ERROR(this->get_logger(), "Compression Exception: %s", e.what());
            return;
        }

        try {
            // 웹소켓 전송
            ws_->write(net::buffer(buffer.data(), buffer.size()));
            
            // [디버그용 로그] 전송 성공 시 1초에 한 번만 출력 (필요시 주석 해제)
            // RCLCPP_INFO_THROTTLE(this->get_logger(), *this->get_clock(), 1000, "Sent %zu bytes", buffer.size());

        } catch (std::exception &e) {
            RCLCPP_ERROR(this->get_logger(), "WebSocket Write Error: %s", e.what());
        }
    }
};

int main(int argc, char * argv[]) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<DracoSenderNode>());
    rclcpp::shutdown();
    return 0;
}